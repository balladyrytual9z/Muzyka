# Muzyka — jedna aplikacja Android

Projekt łączy kod odtwarzacza Auxio z modułem pobierania pochodzącym z YTDLnis w **jednym pakiecie APK**. Ekran startowy jest własnym, poziomym panelem inspirowanym układem multimedialnym CarPlay; nie jest kopią binarną ani oficjalnym interfejsem Apple.

## Co znajduje się w projekcie

- **Odtwarzanie lokalnej muzyki:** ekran biblioteki i odtwarzacz Auxio.
- **Pobieranie:** moduł pobierania jest dołączony do APK; nie wymaga instalowania drugiej aplikacji.
- **Playlisty:** import JSON, CSV i M3U; scalanie duplikatów; filtrowanie po dacie dodania tam, gdzie plik/API udostępnia datę; wysyłanie pozycji do kolejki pobierania.
- **Synchronizacja online:** opcjonalne odświeżanie playlist Spotify i Apple Music co 12 godzin przez Wi-Fi, z opcją „tylko podczas ładowania”.
- **Android 9:** minimalny SDK to 24, więc Android 9/API 28 mieści się w obsługiwanym zakresie.

## Ważne ograniczenia integracji źródeł

1. Do synchronizacji Spotify trzeba wkleić działający token dostępu OAuth. Tokeny wygasają, więc trzeba je odświeżać zgodnie z konfiguracją aplikacji Spotify.
2. Apple Music wymaga poprawnego tokenu deweloperskiego MusicKit/JWT i adresu playlisty. Nie da się wbudować działających prywatnych kluczy Apple ani danych konta Spotify w publiczny projekt.
3. Apple Music API nie zawsze udostępnia datę dodania utworu do playlisty. W takim przypadku pozycja ma status „bez daty” i pozostaje widoczna niezależnie od filtra.
4. Synchronizacja odświeża lokalny spis pozycji. Nie uruchamia automatycznego pobierania każdego nowego utworu w tle; pobieranie wybierasz przyciskiem „Pobierz”.
5. Kod został złożony z dwóch projektów źródłowych, ale nie udało się skompilować go w tym środowisku, ponieważ nie ma połączenia z serwerem dystrybucji Gradle. Kompilacja ma być wykonana w GitHub Actions. Nie traktuj projektu jako zweryfikowanego APK, dopóki workflow nie zakończy się powodzeniem.

## Jak zbudować APK przez GitHub

1. Utwórz puste repozytorium GitHub.
2. Wgraj **zawartość tego ZIP-a**, w tym ukryty katalog `.github/workflows/`.
3. Otwórz **Actions** i uruchom `Build Muzyka (single APK)` (lub wykonaj push do `main`/`master`).
4. Po pomyślnym zakończeniu pobierz artefakt **Drive-Music-single-APK**. Zawiera jeden plik APK.

Workflow sam pobiera wymagane źródła podmodułów Auxio (Media3 i TagLib), instaluje SDK/NDK i buduje wariant `FossDebug`.

## Licencje i pochodzenie

- Kod Auxio zachowuje licencję z pliku `LICENSE-AUXIO`.
- Kod modułu pobierania zachowuje licencję z pliku `LICENSE-YTDLNIS`.
- Zachowano oryginalne pakiety kodu i pliki licencyjne. Sprawdź obowiązki licencyjne przed publikacją lub dystrybucją własnych kompilacji.
