package com.deniscerri.ytdl.ui.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.SharedPreferences
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.view.isVisible
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.paging.PagingDataAdapter
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.deniscerri.ytdl.R
import com.deniscerri.ytdl.database.enums.DownloadType
import com.deniscerri.ytdl.database.models.HistoryItem
import com.deniscerri.ytdl.util.Extensions.loadThumbnail
import com.deniscerri.ytdl.util.Extensions.popup
import com.deniscerri.ytdl.util.FileUtil
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale


class HistoryPaginatedAdapter(onItemClickListener: OnItemClickListener, activity: Activity) : PagingDataAdapter<HistoryItem, HistoryPaginatedAdapter.ViewHolder>(
    DIFF_CALLBACK
) {
    val checkedItems: MutableSet<Long>
    var inverted: Boolean
    private val onItemClickListener: OnItemClickListener
    private val activity: Activity
    private val sharedPreferences: SharedPreferences
    var useDownloadCardDesign: Boolean = false

    init {
        checkedItems = mutableSetOf()
        this.inverted = false
        this.onItemClickListener = onItemClickListener
        this.activity = activity
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(activity)
        useDownloadCardDesign = sharedPreferences.getBoolean("history_use_download_card_design", false)
    }

    class ViewHolder(itemView: View, onItemClickListener: OnItemClickListener?) : RecyclerView.ViewHolder(itemView) {
        val cardView: MaterialCardView

        init {
            cardView = itemView.findViewById(R.id.download_card_view)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryPaginatedAdapter.ViewHolder {
        val layoutRes = when (viewType) {
            TYPE_STANDARD_MULTIPLE -> R.layout.history_card_multiple
            TYPE_DOWNLOAD_CARD_SINGLE -> R.layout.download_card
            TYPE_DOWNLOAD_CARD_MULTIPLE -> R.layout.download_card_multiple
            else -> R.layout.history_card
        }

        val cardView = LayoutInflater.from(parent.context).inflate(layoutRes, parent, false)
        return ViewHolder(cardView, onItemClickListener)
    }

    override fun getItemViewType(position: Int): Int {
        val item = getItem(position) ?: return TYPE_STANDARD_SINGLE
        if (useDownloadCardDesign) {
            return if (item.downloadPath.size == 1) {
                TYPE_DOWNLOAD_CARD_SINGLE
            } else {
                TYPE_DOWNLOAD_CARD_MULTIPLE
            }
        }

        return if (item.downloadPath.size == 1) {
            TYPE_STANDARD_SINGLE
        } else {
            TYPE_STANDARD_MULTIPLE
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun toggleCardDesign() {
        useDownloadCardDesign = !useDownloadCardDesign
        sharedPreferences.edit(commit = true) {
            putBoolean("history_use_download_card_design", useDownloadCardDesign)
        }
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, @SuppressLint("RecyclerView") position: Int) {
        val item = getItem(position) ?: return
        val card = holder.cardView
        holder.itemView.tag = item.id.toString()
        card.tag = item.id.toString()
        card.popup()
        val uiHandler = Handler(Looper.getMainLooper())

        if (getItemViewType(position) == TYPE_STANDARD_SINGLE || getItemViewType(position) == TYPE_STANDARD_MULTIPLE) {
            val thumbnail = card.findViewById<ImageView>(R.id.downloads_image_view)

            // THUMBNAIL ----------------------------------
            val hideThumb = sharedPreferences.getStringSet("hide_thumbnails", emptySet())!!.contains("downloads")
            uiHandler.post { thumbnail.loadThumbnail(hideThumb, item.thumb) }

            // TITLE  ----------------------------------
            val itemTitle = card.findViewById<TextView>(R.id.downloads_title)
            var title = item.title.ifEmpty { item.url }
            if (title.length > 100) {
                title = title.substring(0, 40) + "..."
            }
            itemTitle.text = title

            // Bottom Info ----------------------------------
            val author = card.findViewById<TextView>(R.id.downloads_info_bottom)
            author.text = item.author

            val length = card.findViewById<TextView>(R.id.length)
            length.text = if(item.downloadPath.size == 1) item.duration else ""


            // TIME DOWNLOADED  ----------------------------------
            val datetime = card.findViewById<TextView>(R.id.downloads_info_time)
            datetime.text = SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "ddMMMyyyy - HHmm"), Locale.getDefault()).format(item.time * 1000L)

            // BUTTON ----------------------------------
            val btn = card.findViewById<FloatingActionButton>(R.id.downloads_download_button_type)
            var filesPresent = true

            //IS IN THE FILE SYSTEM?
            if (item.downloadPath.all { !File(it).exists() && it.isNotBlank()}) {
                filesPresent = false
                thumbnail.colorFilter = ColorMatrixColorFilter(object : ColorMatrix() {
                    init {
                        setSaturation(0f)
                    }
                })
                thumbnail.alpha = 0.7f
                btn.backgroundTintList = MaterialColors.getColorStateList(activity, R.attr.colorSurface, ContextCompat.getColorStateList(activity, android.R.color.transparent)!!)
            }else{
                thumbnail.alpha = 1f
                thumbnail.colorFilter = null
                btn.backgroundTintList = MaterialColors.getColorStateList(activity, R.attr.colorPrimaryContainer, ContextCompat.getColorStateList(activity, android.R.color.transparent)!!)
            }

            if (item.type == DownloadType.audio) {
                if (filesPresent) btn.setImageResource(R.drawable.ic_music_downloaded) else {
                    btn.setImageResource(R.drawable.ic_music)
                }
            } else if (item.type == DownloadType.video) {
                if (filesPresent) btn.setImageResource(R.drawable.ic_video_downloaded) else btn.setImageResource(R.drawable.ic_video)
            }else{
                if (filesPresent) btn.setImageResource(R.drawable.ic_terminal) else btn.setImageResource(R.drawable.baseline_code_off_24)
            }
            if (btn.hasOnClickListeners()) btn.setOnClickListener(null)
            btn.isClickable = filesPresent

            if ((checkedItems.contains(item.id) && !inverted) || (!checkedItems.contains(item.id) && inverted)) {
                card.isChecked = true
                card.strokeWidth = 5
            } else {
                card.isChecked = false
                card.strokeWidth = 0
            }
            val finalFilePresent = filesPresent
            card.setOnLongClickListener {
                checkCard(card, item.id, position)
                true
            }
            card.setOnClickListener {
                if (checkedItems.size > 0 || inverted) {
                    checkCard(card, item.id, position)
                } else {
                    onItemClickListener.onCardClick(item.id, finalFilePresent)
                }
            }

            btn.setOnClickListener {
                onItemClickListener.onButtonClick(item.id, finalFilePresent)
            }
        } else {
            val thumbnail = card.findViewById<ImageView>(R.id.downloads_image_view)

            // THUMBNAIL ----------------------------------
            val hideThumb = sharedPreferences.getStringSet("hide_thumbnails", emptySet())!!.contains("downloads")
            uiHandler.post { thumbnail.loadThumbnail(hideThumb, item.thumb) }

            // TITLE  ----------------------------------
            val itemTitle = card.findViewById<TextView>(R.id.title)
            var title = item.title.ifEmpty { item.url }
            if (title.length > 100) {
                title = title.substring(0, 40) + "..."
            }
            itemTitle.text = title

            val length = card.findViewById<TextView>(R.id.duration)
            length.text = if(item.downloadPath.size == 1) item.duration else ""
            length.isVisible = length.text.isNotBlank()

            val author = card.findViewById<TextView>(R.id.download_type)
            author.text = item.author
            author.isVisible = item.author.isNotBlank()

            val formatNote = card.findViewById<TextView>(R.id.format_note)
            formatNote.visibility = View.GONE

            val codec = card.findViewById<TextView>(R.id.codec)
            codec.visibility = View.GONE

            // TIME DOWNLOADED  ----------------------------------
            val datetime = card.findViewById<TextView>(R.id.file_size)
            datetime.text = SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "ddMMMyyyy - HHmm"), Locale.getDefault()).format(item.time * 1000L)

            // BUTTON ----------------------------------
            val btn = card.findViewById<MaterialButton>(R.id.action_button)
            var filesPresent = true

            //IS IN THE FILE SYSTEM?
            if (item.downloadPath.all { !File(it).exists() && it.isNotBlank()}) {
                filesPresent = false
                thumbnail.colorFilter = ColorMatrixColorFilter(object : ColorMatrix() {
                    init {
                        setSaturation(0f)
                    }
                })
                thumbnail.alpha = 0.7f
                btn.backgroundTintList = MaterialColors.getColorStateList(activity, R.attr.colorSurface, ContextCompat.getColorStateList(activity, android.R.color.transparent)!!)
            }else{
                thumbnail.alpha = 1f
                thumbnail.colorFilter = null
                btn.backgroundTintList = MaterialColors.getColorStateList(activity, R.attr.colorSurface, ContextCompat.getColorStateList(activity, android.R.color.transparent)!!)
            }

            if (item.type == DownloadType.audio) {
                if (filesPresent) btn.setIconResource(R.drawable.ic_music_downloaded) else {
                    btn.setIconResource(R.drawable.ic_music)
                }
            } else if (item.type == DownloadType.video) {
                if (filesPresent) btn.setIconResource(R.drawable.ic_video_downloaded) else btn.setIconResource(R.drawable.ic_video)
            }else{
                if (filesPresent) btn.setIconResource(R.drawable.ic_terminal) else btn.setIconResource(R.drawable.baseline_code_off_24)
            }
            if (btn.hasOnClickListeners()) btn.setOnClickListener(null)
            btn.isClickable = filesPresent

            if ((checkedItems.contains(item.id) && !inverted) || (!checkedItems.contains(item.id) && inverted)) {
                card.isChecked = true
                card.strokeWidth = 5
            } else {
                card.isChecked = false
                card.strokeWidth = 0
            }
            val finalFilePresent = filesPresent
            card.setOnLongClickListener {
                checkCard(card, item.id, position)
                true
            }
            card.setOnClickListener {
                if (checkedItems.size > 0 || inverted) {
                    checkCard(card, item.id, position)
                } else {
                    onItemClickListener.onCardClick(item.id, finalFilePresent)
                }
            }

            btn.setOnClickListener {
                onItemClickListener.onButtonClick(item.id, finalFilePresent)
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun clearCheckedItems() {
        inverted = false
        checkedItems.clear()
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun checkAll() {
        checkedItems.clear()
        inverted = true
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun checkMultipleItems(list: List<Long>){
        checkedItems.clear()
        inverted = false
        checkedItems.addAll(list)
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun invertSelected() {
        inverted = !inverted
        notifyDataSetChanged()
    }

    fun getSelectedObjectsCount(totalSize: Int) : Int{
        return if (inverted){
            totalSize - checkedItems.size
        }else{
            checkedItems.size
        }
    }

    private fun checkCard(card: MaterialCardView, itemID: Long, position: Int) {
        if (card.isChecked) {
            card.strokeWidth = 0
            if (inverted) checkedItems.add(itemID)
            else checkedItems.remove(itemID)
        } else {
            card.strokeWidth = 5
            if (inverted) checkedItems.remove(itemID)
            else checkedItems.add(itemID)
        }
        card.isChecked = !card.isChecked
        onItemClickListener.onCardSelect(card.isChecked, position)
    }

    interface OnItemClickListener {
        fun onButtonClick(itemID: Long, filePresent: Boolean)
        fun onCardClick(itemID: Long, filePresent: Boolean)
        fun onCardSelect(isChecked: Boolean, position: Int)
    }

    companion object {
        private const val TYPE_STANDARD_SINGLE = 0
        private const val TYPE_STANDARD_MULTIPLE = 1
        private const val TYPE_DOWNLOAD_CARD_SINGLE = 2
        private const val TYPE_DOWNLOAD_CARD_MULTIPLE = 3

        private val DIFF_CALLBACK: DiffUtil.ItemCallback<HistoryItem> = object : DiffUtil.ItemCallback<HistoryItem>() {
            override fun areItemsTheSame(oldItem: HistoryItem, newItem: HistoryItem): Boolean {
                val ranged = arrayListOf(oldItem.id, newItem.id)
                return ranged[0] == ranged[1]
            }

            override fun areContentsTheSame(oldItem: HistoryItem, newItem: HistoryItem): Boolean {
                return oldItem.time == newItem.time
            }
        }
    }
}