package com.deniscerri.ytdl.util

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Log
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import androidx.preference.PreferenceManager
import com.anggrayudi.storage.callback.FileCallback
import com.anggrayudi.storage.callback.FolderCallback
import com.anggrayudi.storage.file.copyFolderTo
import com.anggrayudi.storage.file.getAbsolutePath
import com.anggrayudi.storage.file.moveFileTo
import com.deniscerri.ytdl.App
import com.deniscerri.ytdl.R
import com.deniscerri.ytdl.core.models.YTDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.internal.closeQuietly
import java.io.File
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.io.path.absolutePathString
import kotlin.math.log10
import kotlin.math.pow


object FileUtil {

    fun deleteFile(path: String){
        runCatching {
            if (!File(path).delete()){
                DocumentFile.fromSingleUri(App.instance, Uri.parse(path))?.delete()
            }
            deleteFileFromMediaStore(path)
        }
    }

    private fun deleteFileFromMediaStore(path: String) {
        val contentResolver = App.instance.contentResolver
        val file = File(path)
        val uri = MediaStore.Files.getContentUri("external")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Query by DATA first to find the exact MediaStore row ID, then delete by ID
            val projection = arrayOf(MediaStore.MediaColumns._ID)
            val selection = MediaStore.MediaColumns.DATA + " =?"
            val selectionArgs = arrayOf(file.absolutePath)

            val rowUri = contentResolver.query(uri, projection, selection, selectionArgs, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID))
                        ContentUris.withAppendedId(uri, id)
                    } else null
                }

            if (rowUri != null) {
                contentResolver.delete(rowUri, null, null)
            }
        } else {
            // Pre-Q: DATA column is reliable
            val selection = MediaStore.MediaColumns.DATA + " =?"
            val selectionArgs = arrayOf(file.absolutePath)
            contentResolver.delete(uri, selection, selectionArgs)
        }
    }

    suspend fun checkExists(path: String): Boolean = withContext(Dispatchers.IO) {
        exists(path)
    }

    fun exists(path: String) : Boolean {
        if (path.isEmpty()) return false
        if (path.startsWith("content://"))
            return runCatching { DocumentFile.fromSingleUri(App.instance, path.toUri())?.exists() == true }.getOrDefault(false)
        return File(path).exists()
    }

    fun formatPath(path: String) : String {
        var dataValue = path
        if (dataValue.startsWith("/storage/")) return dataValue
        dataValue = dataValue.replace("content://com.android.externalstorage.documents/tree/", "")
        dataValue = dataValue.replace("raw:/storage/", "")
        dataValue = dataValue.replace("^/document/".toRegex(), "")
        dataValue = dataValue.replace("^primary:".toRegex(), "primary/")
        dataValue = dataValue.replace("%3A".toRegex(), "/")
        try {
            dataValue = URLDecoder.decode(dataValue, StandardCharsets.UTF_8.name())
        } catch (ignored: Exception) {
        }
        val pieces = dataValue.split("/").toTypedArray()
        val formattedPath = StringBuilder("/storage/")
        if (pieces[0] == "primary"){
            formattedPath.append("emulated/${android.os.Binder.getCallingUserHandle().hashCode()}/")
        }else{
            formattedPath.append(pieces[0]).append("/")
        }
        pieces.forEachIndexed { i, it ->
            if (i > 0 && it.isNotEmpty()){
                formattedPath.append(it).append("/")
            }
        }
        return formattedPath.toString()
    }


    private val SKIP_REGEX = "(^config.*.\\.txt$)|(rList)|(.*.part-Frag.*)|(.*.live_chat)|(.*.ytdl)".toRegex()
    fun isForeignProvider(destDir: String): Boolean {
        if (!destDir.startsWith("content://")) return false
        return destDir.toUri().authority != "com.android.externalstorage.documents"
    }

    private suspend fun moveToProvider(
        originDir: File, context: Context, destDir: String,
        keepCache: Boolean, progress: (p: Int) -> Unit
    ): List<String> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, destDir.toUri())
            ?: throw java.io.IOException("Cannot open destination folder")

        val files = originDir.walkTopDown()
            .filter { it.isFile && it.length() > 0L && !it.name.matches(SKIP_REGEX) }
            .toList()
        val total = files.sumOf { it.length() }.coerceAtLeast(1L)
        var done = 0L
        var lastPct = -1
        val results = mutableListOf<String>()

        for (f in files) {
            // recreate subfolders
            var parent = root
            f.parentFile!!.relativeTo(originDir).path
                .split(File.separatorChar).filter { it.isNotEmpty() && it != "." }
                .forEach { name ->
                    parent = parent.findFile(name)?.takeIf { it.isDirectory }
                        ?: parent.createDirectory(name)
                                ?: throw java.io.IOException("Cannot create folder $name")
                }

            // unique name
            var name = f.name
            var counter = 1
            while (parent.findFile(name) != null) {
                name = "${f.nameWithoutExtension} ($counter)" +
                        (if (f.extension.isNotEmpty()) ".${f.extension}" else "")
                counter++
            }

            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase())
                ?: "application/octet-stream"
            val target = parent.createFile(mime, name)
                ?: throw java.io.IOException("Cannot create $name on destination")

            try {
                context.contentResolver.openOutputStream(target.uri, "w")!!.use { out ->
                    f.inputStream().use { input ->
                        val buf = ByteArray(64 * 1024)
                        var n: Int
                        while (input.read(buf).also { n = it } >= 0) {
                            out.write(buf, 0, n)
                            done += n
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; progress(pct) }
                        }
                    }
                    out.flush()
                }
            } catch (e: Exception) {
                target.delete()          // don't leave a partial file
                throw e
            }

            f.delete()
            results.add(target.uri.toString())
        }

        if (!keepCache) originDir.deleteRecursively()
        results
    }

    @Throws(Exception::class)
     suspend fun moveFile(originDir: File, context: Context, destDir: String, keepCache: Boolean, progress: (p: Int) -> Unit) : List<String> {
        if (isForeignProvider(destDir)) {
            return moveToProvider(originDir, context, destDir, keepCache, progress)
        }
        return withContext(Dispatchers.Main){
            val fileList = mutableListOf<String>()
            val dir = File(formatPath(destDir))
            if (!dir.exists()) dir.mkdirs()
            originDir.walk().forEach {
                if (it.isDirectory && it.absolutePath == originDir.absolutePath) return@forEach
                var destFile: DocumentFile
                try {
                    if (
                        it.name.matches("(^config.*.\\.txt\$)|(rList)|(.*.part-Frag.*)|(.*.live_chat)|(.*.ytdl)".toRegex())
                        || it.length() == 0L
                        ){
                        return@forEach
                    }

                    runCatching {
                        if (File(formatPath(destDir)).canWrite()){
                            val files = it.listFiles()?.filter { fil -> !fil.isDirectory }?.toTypedArray() ?: arrayOf(it)
                            for (ff in files){
                                val newFile =  File(dir.absolutePath + "/${ff.absolutePath.removePrefix(originDir.absolutePath)}")
                                runCatching {
                                    newFile.parentFile?.mkdirs()
                                }
                                if (Build.VERSION.SDK_INT >= 26 ) {
                                    var newFileName = newFile.absolutePath
                                    var counter = 1
                                    while (Files.exists(File(newFileName).toPath())) {
                                        // If the file already exists in the destination directory, add a number to differentiate it
                                        newFileName = newFile.absolutePath.replace(newFile.nameWithoutExtension, newFile.nameWithoutExtension+" ($counter)")
                                        counter++
                                    }

                                    fileList.add(Files.move(
                                        ff.toPath(),
                                        File(newFileName).toPath(),
                                        StandardCopyOption.REPLACE_EXISTING
                                    ).absolutePathString())
                                    ff.delete()
                                    fileList.add(newFileName)
                                }else{
                                    var newFileName = newFile.absolutePath
                                    var counter = 1
                                    while (File(newFileName).exists()) {
                                        // If the file already exists in the destination directory, add a number to differentiate it
                                        newFileName = newFile.absolutePath.replace(newFile.nameWithoutExtension, newFile.nameWithoutExtension+" ($counter)")
                                        counter++
                                    }

                                    ff.copyTo(File(newFileName),false)
                                    ff.delete()
                                    fileList.add(newFileName)
                                }
                            }
                            return@forEach
                        }
                    }

                    val curr = DocumentFile.fromFile(it)
                    val dst =  DocumentFile.fromTreeUri(context, destDir.toUri())

                    if (it.isDirectory){
                        withContext(Dispatchers.IO){
                            curr.copyFolderTo(context, dst!!, skipEmptyFiles = false, callback = object : FolderCallback() {
                                override fun onStart(folder: DocumentFile, totalFilesToCopy: Int, workerThread: Thread): Long {
                                    return 500 // update progress every half second
                                }

                                override fun onParentConflict(destinationFolder: DocumentFile, action: ParentFolderConflictAction, canMerge: Boolean) {
                                    if (canMerge){
                                        action.confirmResolution(ConflictResolution.MERGE)
                                    }else{
                                        action.confirmResolution(ConflictResolution.CREATE_NEW)
                                    }
                                }

                                override fun onReport(report: Report) {
                                    progress(report.progress.toInt())
                                }

                                override fun onCompleted(result: Result) {
                                    fileList.addAll(result.folder.listFiles().map { f -> f.getAbsolutePath(context) })
                                    it.deleteRecursively()
                                }

                                override fun onFailed(errorCode: ErrorCode) {
                                    //if its usb?
                                    runCatching {
                                        it.walkTopDown().forEach { f ->
                                            if (f.isDirectory) return@forEach
                                            val destUri = moveFileInputStream(f, context, dst) ?: return@forEach
                                            fileList.add(DocumentFile.fromSingleUri(context, destUri)!!.getAbsolutePath(context))
                                        }

                                        it.deleteRecursively()
                                    }
                                    super.onFailed(errorCode)
                                }

                            })
                        }
                    }else{
                        withContext(Dispatchers.IO){
                            curr.moveFileTo(context, dst!!, callback = object : FileCallback() {
                                override fun onFailed(errorCode: ErrorCode) {
                                    //if its usb?
                                    runCatching {
                                        val destUri = moveFileInputStream(it, context, dst) ?: return
                                        fileList.add(DocumentFile.fromSingleUri(context, destUri)!!.getAbsolutePath(context))
                                        it.delete()
                                    }
                                    super.onFailed(errorCode)
                                }

                                override fun onConflict(
                                    destinationFile: DocumentFile,
                                    action: FileConflictAction
                                ) {
                                    action.confirmResolution(ConflictResolution.CREATE_NEW)
                                }

                                override fun onStart(file: Any, workerThread: Thread): Long {
                                    return 500 // update progress every 1 second
                                }

                                override fun onReport(report: Report) {
                                    progress(report.progress.toInt())
                                }

                                override fun onCompleted(result: Any) {
                                    destFile = (result as DocumentFile)
                                    fileList.add(destFile.getAbsolutePath(context))
                                    it.delete()
                                    super.onCompleted(result)
                                }
                            })
                        }
                    }
                }catch (e: Exception) {
                    Log.e("error", e.message.toString())
                }

            }
            if (!keepCache){
                originDir.deleteRecursively()
            }
            return@withContext scanMedia(fileList, context)
        }
    }

    private fun moveFileInputStream(it: File, context: Context, dst: DocumentFile) : Uri? {
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(it.extension) ?: "*/*"

        val destUri = DocumentsContract.createDocument(
            context.contentResolver,
            dst.uri,
            mimeType,
            it.name
        ) ?: return null

        val inputStream = it.inputStream()
        val outputStream =
            context.contentResolver.openOutputStream(destUri) ?: return null
        inputStream.copyTo(outputStream)
        inputStream.closeQuietly()
        outputStream.closeQuietly()

        return destUri
    }

    fun scanMedia(files: List<String>, context: Context) : List<String> {
        try {
            val paths = files.distinct().sortedByDescending { File(it).length() }
            runCatching {
                paths.forEach {
                    MediaScannerConnection.scanFile(context, arrayOf(it), null, null)
                }
            }
            return paths.sortedBy { File(it).lastModified() }
        }catch (e: Exception){
            e.printStackTrace()
        }

        return listOf()
    }

    fun getBackupPath(context: Context) : String {
        val preference = PreferenceManager.getDefaultSharedPreferences(context).getString("backup_path", "")
        val path = if (preference.isNullOrBlank()) {
            getDefaultApplicationPath() + "/Backups"
        }else {
            formatPath(preference)
        }
        return path
    }

    fun getCachePath(context: Context) : String {
        val preference = PreferenceManager.getDefaultSharedPreferences(context).getString("cache_path", "")
        if (!preference.isNullOrBlank()) {
            return formatPath(preference)
        }

        val externalPath = context.getExternalFilesDir(null)
        return if (externalPath == null){
            context.cacheDir.absolutePath + "/ytdlnis_cache/"
        }else{
            externalPath.absolutePath + "/ytdlnis_cache/"
        }
    }

    fun getCacheDownloadsPath(context: Context): String {
        return "${getCachePath(context)}dl"
    }

    fun getCacheYTDLPPath(context: Context) : String {
        return "${getCachePath(context)}yt-dlp"
    }

    fun getInfoJsonPath(context: Context) : String {
        return "${getCachePath(context)}infojsons"
    }

    fun deleteConfigFiles(request: YTDLRequest) {
        runCatching {
            request.getArguments("--config")?.forEach {
                if (it != null) File(it).delete()
            }
            request.getArguments("--config-locations")?.forEach {
                if (it != null) File(it).delete()
            }
            request.getArguments("-o")?.firstOrNull { it?.startsWith("infojson:") == true }?.apply {
                File(this.removePrefix("infojson:")).delete()
            }
        }
    }

    fun getDefaultAudioPath() : String{
        return "${getDefaultApplicationPath()}/Audio"
    }

    fun getDefaultVideoPath() : String{
        return "${getDefaultApplicationPath()}/Video"
    }

    fun getDefaultCommandPath() : String {
        return "${getDefaultApplicationPath()}/Command"
    }

    fun getDefaultApksPath() : String {
        return "${getDefaultApplicationPath()}/Apks"
    }

    fun getDefaultTerminalPath() : String {
        return "${getDefaultApplicationPath()}/Terminal"
    }

    fun getDefaultApplicationPath() : String {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)?.absolutePath + File.separator + "YTDLnis"
    }

    fun getDownloadArchivePath(context: Context) : String {
        var folder = PreferenceManager.getDefaultSharedPreferences(context).getString("download_archive_path", "")!!
        if (folder == "") {
            val externalPath = context.getExternalFilesDir(null)
            folder =  if (externalPath == null){
                context.cacheDir.absolutePath + File.separator
            }else{
                externalPath.absolutePath + File.separator
            }
        }
        return "${formatPath(folder)}download_archive.txt"
    }

    fun getBundledYTDLPPluginsPath(context: Context) : String {
        return File(context.filesDir, "yt_dlp_plugins").absolutePath
    }

    fun getCookieFile(context : Context, ignoreIfExists: Boolean = false,  path: (path: String) -> Unit){
        val cookiesFile = File(context.cacheDir, "cookies.txt")
        if (ignoreIfExists || cookiesFile.exists()){
            path(cookiesFile.absolutePath)
        }
    }

    fun convertFileSize(s: Long): String{
        if (s <= 1) return "?"
        val units = arrayOf("B", "kB", "MB", "GB", "TB")
        val digitGroups = (log10(s.toDouble()) / log10(1024.0)).toInt()
        val symbols = DecimalFormatSymbols(Locale.US)
        return "${DecimalFormat("#,##0.#", symbols).format(s / 1024.0.pow(digitGroups.toDouble()))} ${units[digitGroups]}"
    }


    fun openFileIntent(context: Context, downloadPath: String) {
        val uri = if (downloadPath.startsWith("content://")) downloadPath.toUri()
            else runCatching { FileProvider.getUriForFile(context, context.packageName + ".fileprovider", File(downloadPath)) }.getOrNull()

        if (uri == null){
            Toast.makeText(context, "Error opening file!", Toast.LENGTH_SHORT).show()
        }else{
            val ext = downloadPath.substring(downloadPath.lastIndexOf(".") + 1).lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"

            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

            runCatching {
                context.startActivity(intent)
            }.onFailure {
                Toast.makeText(context, it.message ?: "Error opening file!", Toast.LENGTH_SHORT).show()
            }
        }

    }

    fun shareFileIntent(context: Context, paths: List<String>){
        val uris : ArrayList<Uri> = arrayListOf()
        paths.runCatching {
            this.forEach {path ->
                val uri = DocumentFile.fromSingleUri(context, Uri.parse(path)).run{
                    if (this?.exists() == true){
                        this.uri
                    }else if (File(path).exists()){
                        FileProvider.getUriForFile(context, context.packageName + ".fileprovider",
                            File(path))
                    }else null
                }
                if (uri != null) uris.add(uri)
            }

        }

        if (uris.isEmpty()){
            Toast.makeText(context, "Error sharing files!", Toast.LENGTH_SHORT).show()
        }else{
            Intent().apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                action = Intent.ACTION_SEND_MULTIPLE
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                type = if (uris.size == 1) uris[0].let { context.contentResolver.getType(it) } ?: "media/*" else "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }.run{
                context.startActivity(Intent.createChooser(this, context.getString(R.string.share)))
            }
        }
    }

    fun hasAllFilesAccess() : Boolean {
        if (Build.VERSION.SDK_INT < 30) return true
        return Environment.isExternalStorageManager()
    }

}