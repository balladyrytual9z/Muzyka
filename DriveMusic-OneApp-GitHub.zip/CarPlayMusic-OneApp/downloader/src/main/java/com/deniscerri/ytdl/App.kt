package com.deniscerri.ytdl

import android.content.Context
import android.os.Build
import android.os.Looper
import android.webkit.WebView
import android.widget.Toast
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.deniscerri.ytdl.core.RuntimeManager
import com.deniscerri.ytdl.core.models.ExecuteException
import com.deniscerri.ytdl.database.DBManager
import com.deniscerri.ytdl.database.repository.ObserveSourcesRepository
import com.deniscerri.ytdl.util.Extensions.hasReachedEnd
import com.deniscerri.ytdl.util.NotificationUtil
import com.deniscerri.ytdl.util.ObserveAlarmScheduler
import com.deniscerri.ytdl.util.ThemeUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Bootstrap for the embedded downloader module. Auxio remains the single Application class. */
class App private constructor() {
    companion object {
        lateinit var instance: Context
            private set
        private lateinit var applicationScope: CoroutineScope
        private var initialized = false

        @Synchronized
        fun initialize(context: Context) {
            if (initialized) return
            initialized = true
            val app = context.applicationContext as android.app.Application
            instance = app
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(app)
            setDefaultValues(app)
            ThemeUtil.init(app)

            val processName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) android.app.Application.getProcessName() else app.packageName
            if (processName.endsWith(":incognito_process") && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WebView.setDataDirectorySuffix("incognito_store")
                return
            }

            applicationScope = CoroutineScope(SupervisorJob())
            applicationScope.launch(Dispatchers.IO) {
                try {
                    NotificationUtil(app).createNotificationChannel()
                    initLibraries(app)
                    val appVer = sharedPreferences.getString("version", "")!!
                    if (appVer != BuildConfig.VERSION_NAME) {
                        sharedPreferences.edit(commit = true) { putString("version", BuildConfig.VERSION_NAME) }
                    }
                    val db = DBManager.getInstance(app)
                    val scheduler = ObserveAlarmScheduler(app)
                    db.observeSourcesDao.getAllSources()
                        .filter { it.status == ObserveSourcesRepository.SourceStatus.ACTIVE && !it.hasReachedEnd() }
                        .forEach { scheduler.schedule(it) }
                } catch (e: Exception) {
                    e.printStackTrace()
                    if (Looper.myLooper() == null) Looper.prepare()
                    Toast.makeText(app, e.message ?: "Downloader initialization failed", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @Throws(ExecuteException::class)
        private fun initLibraries(context: Context) {
            RuntimeManager.getInstance().init(context)
        }

        private fun setDefaultValues(context: Context) {
            val spl = 1
            val sp = PreferenceManager.getDefaultSharedPreferences(context)
            if (sp.getInt("spl", 0) != spl) {
                PreferenceManager.setDefaultValues(context, R.xml.root_preferences, true)
                PreferenceManager.setDefaultValues(context, R.xml.downloading_preferences, true)
                PreferenceManager.setDefaultValues(context, R.xml.general_preferences, true)
                PreferenceManager.setDefaultValues(context, R.xml.processing_preferences, true)
                PreferenceManager.setDefaultValues(context, R.xml.folders_preference, true)
                PreferenceManager.setDefaultValues(context, R.xml.updating_preferences, true)
                PreferenceManager.setDefaultValues(context, R.xml.ytdlp_update_preferences, true)
                PreferenceManager.setDefaultValues(context, R.xml.app_update_preferences, true)
                PreferenceManager.setDefaultValues(context, R.xml.advanced_preferences, true)
                sp.edit().putInt("spl", spl).apply()
            }
        }
    }
}
