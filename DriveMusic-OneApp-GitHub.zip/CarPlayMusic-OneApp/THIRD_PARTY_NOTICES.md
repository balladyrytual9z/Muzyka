# Third-party source notices

This repository combines two upstream GPL-licensed Android projects:

- Auxio source: https://github.com/OxygenCobalt/Auxio — see `LICENSE-AUXIO` and the original `NOTICE` file.
- YTDLnis source: https://github.com/deniscerri/ytdlnis — see `LICENSE-YTDLNIS`.

Their source files and package namespaces are retained to preserve attribution and source-level licensing. The integrated application display name is Drive Music. The interface is an independent, CarPlay-inspired layout and is not affiliated with Apple.

Dependencies retain their respective upstream licenses. Review all dependency licenses before redistributing a compiled APK.
